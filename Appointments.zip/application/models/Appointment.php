<?php
class Appointment extends CI_Model{
	function getTodaysAppointments($userID)
    {
         // $sql = "SELECT * FROM travel_plans WHERE created_by = ?";
        $sql = "select a.user_id, a.id 'appt_id', date_format(appt_date, '%h:%i %p') 'appt_time', a.tasks, s.status from appointments a join status s on s.id = a.status where appt_Date between curdate() and curdate() + 1 and user_id = ?";
        $vals = [$userID];
        return $this->db->query($sql,$vals)->result_array(); 
	}
    function getFutureAppointments($userID)
    {
        $sql = "select user_id, tasks, date_format(appt_date, '%b %d, %Y') appt_date, date_format(appt_date, '%h:%i %p') 'appt_time' from appointments where appt_date > curdate()+1 and user_id = ?";
        $vals = [$userID];
        return $this->db->query($sql,$vals)->result_array();  
    }

	function addAppointment($apptInfo, $userID, $apptDate)
    {
        $sql = "insert into appointments (user_id, appt_date, tasks, status, created_at,updated_at) values (?,?,?,?,now(),now())";
        $vals = [$userID, $apptDate, $apptInfo['tasks'], 1];
        $this->db->query($sql, $vals);
        return $this->db->insert_id();
    }
    function getAppointmentInfo($apptID) {
        $sql = "select a.id, tasks, date_format(a.appt_date, '%b %d, %Y') 'appt_date', appt_date, date_format(a.appt_date, '%h:%i %p') 'appt_time',  s.status from appointments a join status s on s.id = a.status where a.id = ?";
        $vals = [$apptID];
        return $this->db->query($sql,$vals)->row_array();     
    }
}
?>
