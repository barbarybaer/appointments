<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Destination</title>
	<style type="text/css">
		form{
			margin-top: 50px;
		}
	</style>
</head>
<body>
	<a href="/dashboard">Dashboard</a>
	<a href="/logoff">Logout</a>
<?php		if($this->session->flashdata("update_errors"))
			{
				echo $this->session->flashdata("update_errors");
			}
			
?>	
	<form action="doUpdate/<?=$appt['id']?>" method= "post" id="updateForm"> 
		Tasks: <text><?=$appt['tasks']?></text><br>
		Status: <select name="status">
			<option value="Done">Done</option>
			<option value="Pending">Pending</option>
			<option value="Missed">Missed</option>
		</select><br>
		Date: <input type="date" name="apptDate"/><br>
		Time: <input type="time" name="apptTime" /><br>
		<input type="submit"  value="Update" /><br>
	</form>

</body>
</html>