<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointments extends CI_Controller {
public function __construct()
	{
		parent::__construct();
		$this->output->enable_profiler();
		date_default_timezone_set ( 'America/Los_Angeles' );

	}
	
	public function index() {
		$this->load->model("Appointment");
		$results['todays'] = $this->Appointment->getTodaysAppointments($this->session->userdata['currentUser']['id']); 
		$results['futureAppts'] = $this->Appointment->getFutureAppointments($this->session->userdata['currentUser']['id']);

		
		$results['tDate1'] = date('F m, Y');
		
		$this->load->view('/dashboard',$results);
	}
	
	public function addAppointment() { 
		//echo "in addAppointment";
		$this->load->library("form_validation");
		
		$dateErrors = $this->validateDatesTimes();
		
		$this->form_validation->set_rules("tasks", "tasks","trim|required");
		$this->form_validation->set_rules("apptDate", "apptDate","trim|required");
		$this->form_validation->set_rules("apptTime", "apptTime", "trim|required");

		if($this->form_validation->run() === FALSE || $dateErrors)
		{	//echo "validation errs"; die();
		    $this->session->set_flashdata("addAppt_errors", validation_errors());
			// redirect('Appointments/add', $dateErrors);
			redirect('appointments');
		}
		else
		{	
			//echo "loading appt"; die();
			$this->load->model("Appointment");
			$apptDateTime = date_create($this->input->post('apptDate') . $this->input->post('apptTime'));
			$apptID = $this->Appointment->addAppointment($this->input->post(), $this->session->userdata['currentUser']['id'], date_format($apptDateTime, "Y/m/d H:iP"));

			$this->index();
		}
	}
	public function updateAppointment($apptID){
		$this->load->model("Appointment");
		$results['appt'] = $this->Appointment->getAppointmentInfo($apptID);
		$this->load->view('/update',$results);
	}
	public function doUpdate() {
		echo "in doupdate";die();
		$dateErrors = validateDatesTimes();
		$this->form_validation->set_rules("tasks", "tasks","trim|required");
		$this->form_validation->set_rules("apptDate", "apptDate","trim|required");
		$this->form_validation->set_rules("apptTime", "apptTime", "trim|required");

		if($this->form_validation->run() === FALSE || $dateErrors)
		{	//echo "validation errs"; die();
		    $this->session->set_flashdata("updateAppt_errors", validation_errors());
			// redirect('Appointments/add', $dateErrors);
			redirect('appointments');
		}
		else
			redirect('appointments');
	}
	private function validateDatesTimes() {
		$today = time();
		$apptDate = strtotime($this->input->post('apptDate'));
		$apptTime = $apptDate + strtotime($this->input->post('apptTime'));
		$apptDateTime = date_create($this->input->post('apptDate') . $this->input->post('apptTime'));

		$inputTime = strtotime(date_format($apptDateTime, "Y/m/d H:iP"));
		
		$dateErrors = "";
		if ($inputTime < $today){
			$dateErrors = "Appointment dates cannot occur before now.";
			$this->session->set_flashdata("dateErrors",$dateErrors);
			return $dateErrors;
		}	
	}
}























